var classcmf_1_1water_1_1_null_adsorption =
[
    [ "copy", "classcmf_1_1water_1_1_null_adsorption.html#a95659c4d86b9f9d5daf02ec02d59315a", null ],
    [ "freesolute", "classcmf_1_1water_1_1_null_adsorption.html#ad64db026a886a0967699943ab3a9b300", null ],
    [ "totalsolute", "classcmf_1_1water_1_1_null_adsorption.html#a1de04853f4000ce16ffdc90a6a4bea93", null ]
];