var classcmf_1_1water_1_1_linear_adsorption =
[
    [ "copy", "classcmf_1_1water_1_1_linear_adsorption.html#a29a46a6ed88235369750925e53f09d01", null ],
    [ "freesolute", "classcmf_1_1water_1_1_linear_adsorption.html#a7e415e3d549f3005130ad55c32052ad6", null ],
    [ "totalsolute", "classcmf_1_1water_1_1_linear_adsorption.html#ab0924159cc4b6999b069b73c08e963fb", null ],
    [ "K", "classcmf_1_1water_1_1_linear_adsorption.html#a7d90b68e1f2278aef5d76dc8279058bc", null ],
    [ "m", "classcmf_1_1water_1_1_linear_adsorption.html#a78f16285544f5f895276226acd845d7f", null ]
];