var classcmf_1_1water_1_1_freundlich_adsorbtion =
[
    [ "FreundlichAdsorbtion", "classcmf_1_1water_1_1_freundlich_adsorbtion.html#aa8baba9f906455b942c1d94fb05d1125", null ],
    [ "copy", "classcmf_1_1water_1_1_freundlich_adsorbtion.html#a7fddb8e8f9ae139fd67906f1b7001020", null ],
    [ "freesolute", "classcmf_1_1water_1_1_freundlich_adsorbtion.html#a7e415e3d549f3005130ad55c32052ad6", null ],
    [ "totalsolute", "classcmf_1_1water_1_1_freundlich_adsorbtion.html#ab0924159cc4b6999b069b73c08e963fb", null ],
    [ "epsilon", "classcmf_1_1water_1_1_freundlich_adsorbtion.html#a3ec4d4518a7b5cb7cba8a12cf4dff084", null ],
    [ "K", "classcmf_1_1water_1_1_freundlich_adsorbtion.html#a7d90b68e1f2278aef5d76dc8279058bc", null ],
    [ "m", "classcmf_1_1water_1_1_freundlich_adsorbtion.html#a78f16285544f5f895276226acd845d7f", null ],
    [ "maxiter", "classcmf_1_1water_1_1_freundlich_adsorbtion.html#a274519264a28477940f161ddb4b61feb", null ],
    [ "n", "classcmf_1_1water_1_1_freundlich_adsorbtion.html#af70e2ea2d9616c40cb2717f2a5479871", null ]
];