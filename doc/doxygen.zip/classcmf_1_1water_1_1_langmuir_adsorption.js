var classcmf_1_1water_1_1_langmuir_adsorption =
[
    [ "copy", "classcmf_1_1water_1_1_langmuir_adsorption.html#aaf923b823cbeac868183de1a52d50d84", null ],
    [ "freesolute", "classcmf_1_1water_1_1_langmuir_adsorption.html#a7e415e3d549f3005130ad55c32052ad6", null ],
    [ "totalsolute", "classcmf_1_1water_1_1_langmuir_adsorption.html#ab0924159cc4b6999b069b73c08e963fb", null ]
];