var classcmf_1_1atmosphere_1_1log__wind__profile =
[
    [ "ptr", "classcmf_1_1atmosphere_1_1log__wind__profile.html#aa06042a0c1f24ef10f5e0f56fc737cb1", null ],
    [ "get_aerodynamic_resistance", "classcmf_1_1atmosphere_1_1log__wind__profile.html#a81b50f7bae77b44b785ad678638efd5f", null ]
];