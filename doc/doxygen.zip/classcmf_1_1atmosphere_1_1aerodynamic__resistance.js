var classcmf_1_1atmosphere_1_1aerodynamic__resistance =
[
    [ "ptr", "classcmf_1_1atmosphere_1_1aerodynamic__resistance.html#aa06042a0c1f24ef10f5e0f56fc737cb1", null ],
    [ "get_aerodynamic_resistance", "classcmf_1_1atmosphere_1_1aerodynamic__resistance.html#aae0f3dbca92b1a0d77d80191c30bf640", null ]
];