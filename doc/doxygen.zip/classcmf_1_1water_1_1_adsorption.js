var classcmf_1_1water_1_1_adsorption =
[
    [ "copy", "classcmf_1_1water_1_1_adsorption.html#adee0fa9a890e48a17519cef9d5117240", null ],
    [ "freesolute", "classcmf_1_1water_1_1_adsorption.html#a3cff752a17ff178fbb64fce9922f5d88", null ],
    [ "totalsolute", "classcmf_1_1water_1_1_adsorption.html#a0d167e79581c2943a1b04938daaadfee", null ]
];